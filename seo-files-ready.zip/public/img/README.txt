Place these files in this folder:

1. logo1.jpeg
   Used as favicon, Apple touch icon, and organization logo.

2. mortgage-calculator-social.jpg
   Recommended size: 1200 x 630 pixels.
   Used for Open Graph, WhatsApp, Facebook, LinkedIn, and X/Twitter previews.
