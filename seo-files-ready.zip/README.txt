SEO FILES SETUP

Files included:

- index.html
- public/llms.txt
- public/robots.txt
- public/sitemap.xml
- public/img/README.txt

Before deploying, replace every occurrence of:

https://calculator.example.com/

with your real calculator subdomain.

Also replace:

https://example.com/

with your main website domain.

Add these images:

public/img/logo1.jpeg
public/img/mortgage-calculator-social.jpg

Recommended social image size:

1200 x 630 pixels

After deployment, verify:

https://YOUR_CALCULATOR_DOMAIN/llms.txt
https://YOUR_CALCULATOR_DOMAIN/robots.txt
https://YOUR_CALCULATOR_DOMAIN/sitemap.xml
